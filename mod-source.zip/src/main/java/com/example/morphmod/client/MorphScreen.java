package com.example.morphmod.client;

import com.example.morphmod.Payloads;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;

public class MorphScreen extends Screen {
    private static final int CELL = 26;
    private static final int TOP = 40;
    private boolean blocksTab = false;
    private int scroll = 0;

    public MorphScreen() {
        super(Text.literal("Morph"));
    }

    @Override
    protected void init() {
        int cx = width / 2;
        addDrawableChild(ButtonWidget.builder(Text.literal("Mobs"), b -> { blocksTab = false; scroll = 0; })
                .dimensions(cx - 155, 8, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Blocks"), b -> { blocksTab = true; scroll = 0; })
                .dimensions(cx - 50, 8, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Back to human"), b -> choose(""))
                .dimensions(cx + 55, 8, 100, 20).build());
    }

    private List<Identifier> list() {
        return blocksTab ? MorphModClient.blocks : MorphModClient.mobs;
    }

    private int cols() { return Math.max(1, (width - 40) / CELL); }
    private int left() { return (width - cols() * CELL) / 2; }
    private int visibleRows() { return Math.max(1, (height - TOP - 10) / CELL); }
    private int totalRows() { return (list().size() + cols() - 1) / cols(); }

    private ItemStack iconFor(Identifier id) {
        if (blocksTab) return new ItemStack(Registries.BLOCK.get(id).asItem());
        SpawnEggItem egg = SpawnEggItem.forEntity(Registries.ENTITY_TYPE.get(id));
        return new ItemStack(egg != null ? egg : Items.BARRIER);
    }

    private Text nameFor(Identifier id) {
        return blocksTab ? Registries.BLOCK.get(id).getName() : Registries.ENTITY_TYPE.get(id).getName();
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        ctx.fill(0, 0, width, height, 0xB0000000);
        super.render(ctx, mx, my, delta);

        List<Identifier> l = list();
        if (l.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer,
                    Text.literal(blocksTab ? "Break blocks to unlock them" : "Kill mobs to unlock them"),
                    width / 2, height / 2, 0xFFAAAAAA);
            return;
        }
        Text hoverName = null;
        int cols = cols(), left = left();
        for (int row = 0; row < visibleRows(); row++) {
            for (int col = 0; col < cols; col++) {
                int i = (row + scroll) * cols + col;
                if (i >= l.size()) break;
                int x = left + col * CELL, y = TOP + row * CELL;
                boolean hover = mx >= x && mx < x + CELL - 2 && my >= y && my < y + CELL - 2;
                ctx.fill(x, y, x + CELL - 2, y + CELL - 2, hover ? 0x80FFFFFF : 0x60000000);
                ctx.drawItem(iconFor(l.get(i)), x + 4, y + 4);
                if (hover) hoverName = nameFor(l.get(i));
            }
        }
        if (hoverName != null) ctx.drawTooltip(textRenderer, hoverName, mx, my);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (super.mouseClicked(mx, my, button)) return true;
        List<Identifier> l = list();
        int col = (int) ((mx - left()) / CELL), row = (int) ((my - TOP) / CELL);
        if (mx < left() || my < TOP || col >= cols() || row >= visibleRows()) return false;
        int i = (row + scroll) * cols() + col;
        if (i >= 0 && i < l.size()) {
            choose((blocksTab ? "b:" : "m:") + l.get(i));
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        int max = Math.max(0, totalRows() - visibleRows());
        scroll = Math.max(0, Math.min(max, scroll - (int) Math.signum(v)));
        return true;
    }

    private void choose(String morph) {
        ClientPlayNetworking.send(new Payloads.MorphRequest(morph));
        close();
    }
}
