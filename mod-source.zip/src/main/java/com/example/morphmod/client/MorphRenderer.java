package com.example.morphmod.client;

import com.example.morphmod.MorphMod;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Draws a morphed player as a (never-spawned) copy of the mob, or as a block. */
public final class MorphRenderer {
    static final Map<UUID, LivingEntity> DUMMIES = new HashMap<>();

    private MorphRenderer() {}

    private static LivingEntity dummy(AbstractClientPlayerEntity p, Identifier id) {
        LivingEntity d = DUMMIES.get(p.getUuid());
        if (d == null) {
            Entity e = Registries.ENTITY_TYPE.get(id).create(p.getWorld());
            if (e instanceof LivingEntity le) {
                d = le;
                DUMMIES.put(p.getUuid(), d);
            }
        }
        return d;
    }

    /** Drives the walking animation of each dummy once per tick. */
    public static void tick(MinecraftClient c) {
        if (c.world == null) return;
        for (AbstractClientPlayerEntity p : c.world.getPlayers()) {
            String s = MorphMod.CLIENT_MORPHS.get(p.getUuid());
            if (s == null || !s.startsWith("m:")) continue;
            Identifier id = Identifier.tryParse(s.substring(2));
            if (id == null) continue;
            LivingEntity d = dummy(p, id);
            if (d == null) continue;
            float speed = Math.min(MathHelper.hypot((float) (p.getX() - p.prevX), (float) (p.getZ() - p.prevZ)) * 4f, 1f);
            d.limbAnimator.updateLimbs(speed, 0.4f);
        }
    }

    public static boolean render(AbstractClientPlayerEntity p, EntityRenderDispatcher disp, double x, double y,
                                 double z, float yaw, float td, MatrixStack m, VertexConsumerProvider vc, int light) {
        String s = MorphMod.CLIENT_MORPHS.get(p.getUuid());
        if (s == null || s.length() < 3) return false;
        Identifier id = Identifier.tryParse(s.substring(2));
        if (id == null) return false;

        if (s.startsWith("b:")) {
            BlockState state = Registries.BLOCK.get(id).getDefaultState();
            m.push();
            m.translate(x - 0.5, y, z - 0.5);
            MinecraftClient.getInstance().getBlockRenderManager()
                    .renderBlockAsEntity(state, m, vc, light, OverlayTexture.DEFAULT_UV);
            m.pop();
            return true;
        }

        LivingEntity d = dummy(p, id);
        if (d == null) return false;
        d.setPos(p.getX(), p.getY(), p.getZ());
        d.prevX = p.prevX; d.prevY = p.prevY; d.prevZ = p.prevZ;
        d.lastRenderX = p.lastRenderX; d.lastRenderY = p.lastRenderY; d.lastRenderZ = p.lastRenderZ;
        d.setYaw(p.getYaw()); d.prevYaw = p.prevYaw;
        d.setPitch(p.getPitch()); d.prevPitch = p.prevPitch;
        d.bodyYaw = p.bodyYaw; d.prevBodyYaw = p.prevBodyYaw;
        d.headYaw = p.headYaw; d.prevHeadYaw = p.prevHeadYaw;
        d.age = p.age;
        d.hurtTime = p.hurtTime;
        d.handSwingProgress = p.handSwingProgress;
        d.lastHandSwingProgress = p.lastHandSwingProgress;
        d.setOnGround(p.isOnGround());
        disp.render(d, x, y, z, yaw, td, m, vc, light);
        return true;
    }
}
