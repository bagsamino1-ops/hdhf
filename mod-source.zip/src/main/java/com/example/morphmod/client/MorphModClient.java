package com.example.morphmod.client;

import com.example.morphmod.MorphMod;
import com.example.morphmod.Payloads;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class MorphModClient implements ClientModInitializer {
    public static List<Identifier> mobs = new ArrayList<>();
    public static List<Identifier> blocks = new ArrayList<>();
    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.morphmod.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F, "category.morphmod"));

        ClientPlayNetworking.registerGlobalReceiver(Payloads.SyncUnlocks.ID, (pl, ctx) -> {
            mobs = new ArrayList<>(pl.mobs());
            blocks = new ArrayList<>(pl.blocks());
        });

        ClientPlayNetworking.registerGlobalReceiver(Payloads.MorphUpdate.ID, (pl, ctx) -> {
            if (pl.morph().isEmpty()) MorphMod.CLIENT_MORPHS.remove(pl.player());
            else MorphMod.CLIENT_MORPHS.put(pl.player(), pl.morph());
            MorphRenderer.DUMMIES.remove(pl.player());
            if (ctx.client().world != null) {
                PlayerEntity p = ctx.client().world.getPlayerByUuid(pl.player());
                if (p != null) p.calculateDimensions();
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (openKey.wasPressed()) {
                if (c.currentScreen == null && c.player != null) c.setScreen(new MorphScreen());
            }
            MorphRenderer.tick(c);
        });

        ClientPlayConnectionEvents.DISCONNECT.register((h, c) -> {
            MorphMod.CLIENT_MORPHS.clear();
            MorphRenderer.DUMMIES.clear();
            mobs = new ArrayList<>();
            blocks = new ArrayList<>();
        });
    }
}
