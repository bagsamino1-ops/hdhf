package com.example.morphmod.mixin;

import com.example.morphmod.MorphMod;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin {
    /** Morphed players get the hitbox of what they morphed into (server and client). */
    @Inject(method = "getBaseDimensions", at = @At("HEAD"), cancellable = true)
    private void morph$dimensions(EntityPose pose, CallbackInfoReturnable<EntityDimensions> cir) {
        String m = MorphMod.getMorph((PlayerEntity) (Object) this);
        if (m.length() < 3) return;
        if (m.startsWith("b:")) {
            cir.setReturnValue(EntityDimensions.fixed(0.98f, 0.98f));
        } else if (m.startsWith("m:")) {
            Identifier id = Identifier.tryParse(m.substring(2));
            if (id == null) return;
            EntityDimensions d = Registries.ENTITY_TYPE.get(id).getDimensions();
            float big = Math.max(d.width(), d.height());
            if (big > 3f) d = d.scaled(3f / big); // keep giants playable
            cir.setReturnValue(d);
        }
    }
}
