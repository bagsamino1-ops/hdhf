package com.example.morphmod.mixin;

import com.example.morphmod.client.MorphRenderer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(EntityRenderDispatcher.class)
public abstract class EntityRenderDispatcherMixin {
    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFFLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At("HEAD"), cancellable = true)
    private void morph$render(Entity entity, double x, double y, double z, float yaw, float tickDelta,
                              MatrixStack matrices, VertexConsumerProvider vc, int light, CallbackInfo ci) {
        if (entity instanceof AbstractClientPlayerEntity p
                && MorphRenderer.render(p, (EntityRenderDispatcher) (Object) this, x, y, z, yaw, tickDelta, matrices, vc, light)) {
            ci.cancel();
        }
    }
}
