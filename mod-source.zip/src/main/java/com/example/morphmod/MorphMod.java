package com.example.morphmod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityCombatEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.DefaultAttributeRegistry;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.registry.tag.EntityTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MorphMod implements ModInitializer {
    public static final String ID = "morphmod";

    /** Client-side copy of who is morphed into what (only touched when world.isClient). */
    public static final Map<UUID, String> CLIENT_MORPHS = new HashMap<>();

    public static final AttachmentType<MorphData> DATA = AttachmentRegistry.create(
            Identifier.of(ID, "data"), b -> b.persistent(MorphData.CODEC).copyOnDeath());

    // ---- tweakable mob ability tables ----
    private static final Set<EntityType<?>> FLYERS = Set.of(EntityType.BAT, EntityType.BEE, EntityType.ALLAY,
            EntityType.VEX, EntityType.PHANTOM, EntityType.GHAST, EntityType.BLAZE, EntityType.PARROT,
            EntityType.ENDER_DRAGON);
    private static final Set<EntityType<?>> SLOW_FALL = Set.of(EntityType.CHICKEN, EntityType.PARROT);
    private static final Set<EntityType<?>> NIGHT_VISION = Set.of(EntityType.BAT, EntityType.SPIDER,
            EntityType.CAVE_SPIDER, EntityType.CAT, EntityType.OCELOT);
    private static final Map<EntityType<?>, Integer> JUMP = Map.of(EntityType.RABBIT, 2, EntityType.FROG, 1,
            EntityType.GOAT, 2, EntityType.SLIME, 1);

    private static final List<RegistryEntry<StatusEffect>> MANAGED = List.of(StatusEffects.FIRE_RESISTANCE,
            StatusEffects.WATER_BREATHING, StatusEffects.SLOW_FALLING, StatusEffects.NIGHT_VISION,
            StatusEffects.JUMP_BOOST);
    private static final List<RegistryEntry<EntityAttribute>> ATTRS = List.of(EntityAttributes.GENERIC_MAX_HEALTH,
            EntityAttributes.GENERIC_MOVEMENT_SPEED, EntityAttributes.GENERIC_ATTACK_DAMAGE, EntityAttributes.GENERIC_ARMOR);

    @Override
    public void onInitialize() {
        PayloadTypeRegistry.playS2C().register(Payloads.SyncUnlocks.ID, Payloads.SyncUnlocks.CODEC);
        PayloadTypeRegistry.playS2C().register(Payloads.MorphUpdate.ID, Payloads.MorphUpdate.CODEC);
        PayloadTypeRegistry.playC2S().register(Payloads.MorphRequest.ID, Payloads.MorphRequest.CODEC);

        ServerPlayNetworking.registerGlobalReceiver(Payloads.MorphRequest.ID,
                (payload, ctx) -> requestMorph(ctx.player(), payload.morph()));

        // Unlock mobs on kill
        ServerEntityCombatEvents.AFTER_KILLED_OTHER_ENTITY.register((world, killer, victim) -> {
            if (killer instanceof ServerPlayerEntity p && !(victim instanceof PlayerEntity)
                    && DefaultAttributeRegistry.hasDefinitionFor(victim.getType())) {
                unlock(p, false, Registries.ENTITY_TYPE.getId(victim.getType()));
            }
        });

        // Unlock blocks on break
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (player instanceof ServerPlayerEntity sp && state.getBlock().asItem() != Items.AIR) {
                unlock(sp, true, Registries.BLOCK.getId(state.getBlock()));
            }
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayerEntity p = handler.player;
            sendUnlocks(p);
            for (ServerPlayerEntity o : server.getPlayerManager().getPlayerList()) {
                String m = getData(o).current();
                if (!m.isEmpty()) ServerPlayNetworking.send(p, new Payloads.MorphUpdate(o.getUuid(), m));
            }
            applyMorph(p);
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
            if (!alive) newP.setAttached(DATA, getData(newP).withCurrent(""));
            sendUnlocks(newP);
            applyMorph(newP);
        });

        // Block morph super power: never hungry
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTicks() % 20 != 0) return;
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                if (getData(p).current().startsWith("b:")) p.getHungerManager().setFoodLevel(20);
            }
        });
    }

    public static MorphData getData(PlayerEntity p) {
        return p.getAttachedOrElse(DATA, MorphData.EMPTY);
    }

    public static String getMorph(PlayerEntity p) {
        if (p.getWorld().isClient()) return CLIENT_MORPHS.getOrDefault(p.getUuid(), "");
        return getData(p).current();
    }

    // ---------- unlocking ----------
    private static void unlock(ServerPlayerEntity p, boolean block, Identifier id) {
        MorphData d = getData(p);
        if ((block ? d.blocks() : d.mobs()).contains(id)) return;
        p.setAttached(DATA, block ? d.withBlock(id) : d.withMob(id));
        sendUnlocks(p);
        Text name = block ? Registries.BLOCK.get(id).getName() : Registries.ENTITY_TYPE.get(id).getName();
        p.sendMessage(Text.literal("Morph unlocked: ").append(name), true);
    }

    private static void sendUnlocks(ServerPlayerEntity p) {
        MorphData d = getData(p);
        ServerPlayNetworking.send(p, new Payloads.SyncUnlocks(d.mobs(), d.blocks()));
    }

    // ---------- morphing ----------
    private static void requestMorph(ServerPlayerEntity p, String m) {
        MorphData d = getData(p);
        if (!m.isEmpty()) {
            if (m.length() < 3) return;
            boolean block = m.startsWith("b:");
            if (!block && !m.startsWith("m:")) return;
            Identifier id = Identifier.tryParse(m.substring(2));
            if (id == null || !(block ? d.blocks() : d.mobs()).contains(id)) return;
        }
        p.setAttached(DATA, d.withCurrent(m));
        applyMorph(p);
    }

    private static void applyMorph(ServerPlayerEntity p) {
        String m = getData(p).current();
        float ratio = p.getHealth() / Math.max(1f, p.getMaxHealth());

        // reset everything we may have changed
        for (RegistryEntry<EntityAttribute> a : ATTRS) {
            EntityAttributeInstance inst = p.getAttributeInstance(a);
            if (inst != null) inst.removeModifier(modId(a));
        }
        for (RegistryEntry<StatusEffect> e : MANAGED) {
            StatusEffectInstance cur = p.getStatusEffect(e);
            if (cur != null && cur.isInfinite()) p.removeStatusEffect(e);
        }
        PlayerAbilities ab = p.getAbilities();
        boolean special = p.isCreative() || p.isSpectator();
        ab.allowFlying = special;
        if (!special) ab.flying = false;
        ab.invulnerable = special;

        if (m.startsWith("m:")) {
            Identifier id = Identifier.tryParse(m.substring(2));
            if (id != null) applyMob(p, Registries.ENTITY_TYPE.get(id));
        } else if (m.startsWith("b:")) {
            // SUPER FEATURES for blocks: invulnerable, fire-proof, breathes underwater, never hungry
            ab.invulnerable = true;
            give(p, StatusEffects.FIRE_RESISTANCE, 0);
            give(p, StatusEffects.WATER_BREATHING, 0);
        }

        p.sendAbilitiesUpdate();
        p.setHealth(Math.max(1f, Math.min(p.getMaxHealth(), ratio * p.getMaxHealth())));
        p.calculateDimensions();

        Payloads.MorphUpdate u = new Payloads.MorphUpdate(p.getUuid(), m);
        for (ServerPlayerEntity o : PlayerLookup.all(p.getServer())) ServerPlayNetworking.send(o, u);
    }

    @SuppressWarnings("unchecked")
    private static void applyMob(ServerPlayerEntity p, EntityType<?> t) {
        if (DefaultAttributeRegistry.hasDefinitionFor(t)) {
            DefaultAttributeContainer c = DefaultAttributeRegistry.get((EntityType<? extends LivingEntity>) t);
            mod(p, EntityAttributes.GENERIC_MAX_HEALTH, c, 1.0);
            mod(p, EntityAttributes.GENERIC_MOVEMENT_SPEED, c, 0.5); // tune: how much of the mob's speed you get
            mod(p, EntityAttributes.GENERIC_ATTACK_DAMAGE, c, 1.0);
            mod(p, EntityAttributes.GENERIC_ARMOR, c, 1.0);
        }
        if (t.isFireImmune()) give(p, StatusEffects.FIRE_RESISTANCE, 0);
        SpawnGroup g = t.getSpawnGroup();
        if (t.isIn(EntityTypeTags.CAN_BREATHE_UNDER_WATER) || g == SpawnGroup.WATER_CREATURE
                || g == SpawnGroup.WATER_AMBIENT || g == SpawnGroup.UNDERGROUND_WATER_CREATURE
                || g == SpawnGroup.AXOLOTLS) {
            give(p, StatusEffects.WATER_BREATHING, 0);
        }
        if (FLYERS.contains(t)) p.getAbilities().allowFlying = true;
        if (SLOW_FALL.contains(t)) give(p, StatusEffects.SLOW_FALLING, 0);
        if (NIGHT_VISION.contains(t)) give(p, StatusEffects.NIGHT_VISION, 0);
        if (JUMP.containsKey(t)) give(p, StatusEffects.JUMP_BOOST, JUMP.get(t));
    }

    private static Identifier modId(RegistryEntry<EntityAttribute> a) {
        return Identifier.of(ID, "morph_" + a.getKey().map(k -> k.getValue().getPath()).orElse("x"));
    }

    private static void mod(ServerPlayerEntity p, RegistryEntry<EntityAttribute> attr,
                            DefaultAttributeContainer c, double scale) {
        EntityAttributeInstance inst = p.getAttributeInstance(attr);
        if (inst == null || !c.has(attr)) return;
        double delta = (c.getValue(attr) - inst.getBaseValue()) * scale;
        inst.addTemporaryModifier(new EntityAttributeModifier(modId(attr), delta,
                EntityAttributeModifier.Operation.ADD_VALUE));
    }

    private static void give(ServerPlayerEntity p, RegistryEntry<StatusEffect> e, int amp) {
        p.addStatusEffect(new StatusEffectInstance(e, StatusEffectInstance.INFINITE, amp, false, false, false));
    }
}
