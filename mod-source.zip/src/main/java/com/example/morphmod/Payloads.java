package com.example.morphmod;

import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;

import java.util.List;
import java.util.UUID;

public final class Payloads {
    private Payloads() {}

    /** Server -> client: everything this player has unlocked. */
    public record SyncUnlocks(List<Identifier> mobs, List<Identifier> blocks) implements CustomPayload {
        public static final CustomPayload.Id<SyncUnlocks> ID = new CustomPayload.Id<>(Identifier.of(MorphMod.ID, "sync_unlocks"));
        public static final PacketCodec<ByteBuf, SyncUnlocks> CODEC = PacketCodec.tuple(
                Identifier.PACKET_CODEC.collect(PacketCodecs.toList()), SyncUnlocks::mobs,
                Identifier.PACKET_CODEC.collect(PacketCodecs.toList()), SyncUnlocks::blocks,
                SyncUnlocks::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Server -> all clients: this player is now morphed into X ("" = human). */
    public record MorphUpdate(UUID player, String morph) implements CustomPayload {
        public static final CustomPayload.Id<MorphUpdate> ID = new CustomPayload.Id<>(Identifier.of(MorphMod.ID, "morph_update"));
        public static final PacketCodec<ByteBuf, MorphUpdate> CODEC = PacketCodec.tuple(
                Uuids.PACKET_CODEC, MorphUpdate::player,
                PacketCodecs.STRING, MorphUpdate::morph,
                MorphUpdate::new);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }

    /** Client -> server: please morph me into X. */
    public record MorphRequest(String morph) implements CustomPayload {
        public static final CustomPayload.Id<MorphRequest> ID = new CustomPayload.Id<>(Identifier.of(MorphMod.ID, "morph_request"));
        public static final PacketCodec<ByteBuf, MorphRequest> CODEC =
                PacketCodecs.STRING.xmap(MorphRequest::new, MorphRequest::morph);
        @Override public CustomPayload.Id<? extends CustomPayload> getId() { return ID; }
    }
}
