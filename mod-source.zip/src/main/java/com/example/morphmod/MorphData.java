package com.example.morphmod;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/** current = "" (human), "m:minecraft:zombie" (mob) or "b:minecraft:stone" (block) */
public record MorphData(List<Identifier> mobs, List<Identifier> blocks, String current) {
    public static final MorphData EMPTY = new MorphData(List.of(), List.of(), "");

    public static final Codec<MorphData> CODEC = RecordCodecBuilder.create(i -> i.group(
            Identifier.CODEC.listOf().fieldOf("mobs").forGetter(MorphData::mobs),
            Identifier.CODEC.listOf().fieldOf("blocks").forGetter(MorphData::blocks),
            Codec.STRING.fieldOf("current").forGetter(MorphData::current)
    ).apply(i, MorphData::new));

    public MorphData withMob(Identifier id) {
        List<Identifier> l = new ArrayList<>(mobs);
        l.add(id);
        return new MorphData(l, blocks, current);
    }

    public MorphData withBlock(Identifier id) {
        List<Identifier> l = new ArrayList<>(blocks);
        l.add(id);
        return new MorphData(mobs, l, current);
    }

    public MorphData withCurrent(String c) {
        return new MorphData(mobs, blocks, c);
    }
}
